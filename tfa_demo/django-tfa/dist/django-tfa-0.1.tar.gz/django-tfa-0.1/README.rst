=====
Django Two Factor Authentication
=====

Django TFA is a simple Django app to add two factor authentication to your Django projects super quickly!

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "django_twilio_tfa" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'django_twilio_tfa',
    ]

2. Include the polls URLconf in your project urls.py like this::

    url(r'^tfa/', include('django_twilio_tfa.urls')),

3. Run `python manage.py migrate` to create the django_twilio_tfa models.

4. Whenever a new user registers on your site, use the "register_user_tfa" signal to enable Two Factor Authentication for this user.

